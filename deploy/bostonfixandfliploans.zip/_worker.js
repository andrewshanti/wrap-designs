const RULES = [
{
"re": "^/bad\\-credit\\-loans/?$",
"to": "/bad-credit-dscr-loans/",
"code": 301
},
{
"re": "^/easy\\-50/?$",
"to": "/bad-credit-dscr-loans/",
"code": 301
},
{
"re": "^/faq\\-hilton\\-head\\-hard\\-money\\-loan/?$",
"to": "/faq/",
"code": 301
},
{
"re": "^/mailinform/?$",
"to": "/contact/",
"code": 301
},
{
"re": "^/blog\\-2/?$",
"to": "/blog/",
"code": 301
},
{
"re": "^/about/?$",
"to": "/about-us/",
"code": 301
},
{
"re": "^/free\\-analysis\\-report\\-hard\\-money\\-lender/?$",
"to": "/contact/",
"code": 301
},
{
"re": "^/hard\\-money\\-loan\\-sc\\-newsletter/?$",
"to": "/blog/",
"code": 301
},
{
"re": "^/hard\\-money\\-loan\\-packages/?$",
"to": "/hard-money-loan-programs/",
"code": 301
},
{
"re": "^/testing\\-home/?$",
"to": "/",
"code": 301
},
{
"re": "^/hard\\-money\\-hard\\-money\\-loans/?$",
"to": "/fix-and-flip-loans/",
"code": 301
},
{
"re": "^/bostinfix\\.xml/?$",
"to": "/sitemap.xml",
"code": 301
},
{
"re": "^/(?:dscr-loans|hard-money-loans|asset-based-lending)/massachusetts/(boston|worcester|springfield|cambridge|lowell|brockton|quincy|lynn|new-bedford|fall-river)/?$",
"to": "/massachusetts/$1/",
"code": 301
},
{
"re": "^/(?:dscr-loans/|hard-money-loans/|asset-based-lending/)?massachusetts/(?:allston|brighton|charlestown|dorchester|dorchester-center|east-boston|hyde-park|jamaica-plain|mattapan|roslindale|roxbury|roxbury-crossing|south-boston|west-roxbury)/?$",
"to": "/massachusetts/boston/",
"code": 301
},
{
"re": "^/dscr-loans/massachusetts/[^/]+/?$",
"to": "/dscr-rental-loans/",
"code": 301
},
{
"re": "^/(?:hard-money-loans|asset-based-lending)/massachusetts/[^/]+/?$",
"to": "/hard-money-loan-programs/",
"code": 301
},
{
"re": "^/massachusetts/(?!(?:boston|worcester|springfield|cambridge|lowell|brockton|quincy|lynn|new-bedford|fall-river)/?$)[^/]+/?$",
"to": "/massachusetts/",
"code": 301
},
{
"re": "^/(?:fix-and-flip-loans|dscr-loans|hard-money-loans|asset-based-lending)-in-mpg_city/?$",
"to": "/hard-money-loan-programs/",
"code": 301
},
{
"re": "^/uncategorized/?$",
"to": "/blog/",
"code": 301
}
].map(r => ({re: new RegExp(r.re, 'i'), to: r.to, code: r.code}));
const SEC = {'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN'};
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.hostname.startsWith('www.')) { url.hostname = url.hostname.slice(4); return Response.redirect(url.toString(), 301); }
    let res = await env.ASSETS.fetch(request);
    if (res.status === 404) {
      for (const r of RULES) {
        const m = url.pathname.match(r.re);
        if (m) { const t = r.to.replace(/\$(\d)/g, (_, i) => m[i] || ''); return Response.redirect(new URL(t, url.origin).toString(), r.code || 301); }
      }
    }
    res = new Response(res.body, res);
    for (const [k, v] of Object.entries(SEC)) res.headers.set(k, v);
    if (url.hostname.endsWith('.pages.dev')) res.headers.set('X-Robots-Tag', 'noindex');
    return res;
  }
};
