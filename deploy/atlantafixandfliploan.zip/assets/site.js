(function () {
  var menu = document.getElementById('mobile-menu');
  var openBtn = document.querySelector('.bff-header-row .nav-toggle');
  var closeBtn = document.querySelector('.nav-close');
  if (!menu || !openBtn) return;
  function set(open) {
    menu.hidden = !open;
    openBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.classList.toggle('menu-open', open);
    if (open) { closeBtn.focus(); } else { openBtn.focus(); }
  }
  openBtn.addEventListener('click', function () { set(true); });
  closeBtn.addEventListener('click', function () { set(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) set(false); });
  menu.addEventListener('click', function (e) { if (e.target.closest('a')) { menu.hidden = true; document.body.classList.remove('menu-open'); } });
  window.matchMedia('(min-width: 901px)').addEventListener('change', function (m) { if (m.matches && !menu.hidden) set(false); });
})();
